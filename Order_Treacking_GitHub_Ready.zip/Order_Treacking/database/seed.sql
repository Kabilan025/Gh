USE logistics_tracking;

INSERT INTO users (name, email, password_hash, role, google_sub)
VALUES
  ('Ava Carter', 'user@logistics.com', 'GENERATED_BY_FLASK_SEED', 'user', NULL),
  ('Admin One', 'admin@logistics.com', 'GENERATED_BY_FLASK_SEED', 'admin', NULL);

INSERT INTO drivers (name, phone, license_number, availability)
VALUES
  ('Ravi Kumar', '+91-9876543210', 'LIC-RAVI-001', 'assigned'),
  ('Sonia Patel', '+91-9988776655', 'LIC-SONIA-002', 'assigned'),
  ('Arjun Mehta', '+91-9090909090', 'LIC-ARJUN-003', 'unavailable');

INSERT INTO vehicles (vehicle_number, route_details, source, destination, latitude, longitude, current_eta, fastag_expiry_date, status, driver_id)
VALUES
  ('MH12AB1234', 'Mumbai Hub -> Pune DC', 'Mumbai', 'Pune', 18.520400, 73.856700, 'Today, 8:30 PM', CURDATE() + INTERVAL 2 DAY, 'In Transit', 1),
  ('DL8CAF7788', 'Delhi Hub -> Jaipur DC', 'Delhi', 'Jaipur', 28.613900, 77.209000, 'Tomorrow, 2:00 PM', CURDATE() - INTERVAL 1 DAY, 'Scheduled', 2),
  ('KA01XY2211', 'Bangalore Hub -> Chennai DC', 'Bangalore', 'Chennai', 12.971600, 77.594600, 'Tomorrow, 11:15 AM', CURDATE() + INTERVAL 12 DAY, 'Maintenance', NULL);

INSERT INTO orders (tracking_number, customer_name, origin, destination, status, eta, ordered_at, packed_at, shipped_at, out_for_delivery_at, delayed_at, user_id, vehicle_id, driver_id)
VALUES
  ('ORD-1001', 'Ava Carter', 'Mumbai', 'Pune', 'shipped', 'Today, 8:30 PM', NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 44 HOUR, NOW() - INTERVAL 1 DAY, NULL, NULL, 1, 1, 1),
  ('ORD-1002', 'Ava Carter', 'Delhi', 'Jaipur', 'delayed', 'Tomorrow, 2:00 PM', NOW() - INTERVAL 3 DAY, NOW() - INTERVAL 2 DAY, NULL, NULL, NOW() - INTERVAL 5 HOUR, 1, 2, 2),
  ('ORD-1003', 'Ava Carter', 'Bangalore', 'Chennai', 'out_for_delivery', 'Today, 6:45 PM', NOW() - INTERVAL 32 HOUR, NOW() - INTERVAL 28 HOUR, NOW() - INTERVAL 12 HOUR, NOW() - INTERVAL 2 HOUR, NULL, 1, 3, NULL);

INSERT INTO payments (reference, amount, method, status, paid_at, user_id, order_id)
VALUES
  ('PAY-5001', 249.99, 'UPI', 'paid', NOW(), 1, 1),
  ('PAY-5002', 149.50, 'Card', 'pending', NULL, 1, 2),
  ('PAY-5003', 319.00, 'Net Banking', 'failed', NULL, 1, 3);
