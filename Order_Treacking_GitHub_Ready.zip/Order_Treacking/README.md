# Logistics & Tracking System

A full-stack starter for a logistics dashboard with user and admin flows, vehicle management, order and payment tracking, a floating support chatbot, and a dark neon-inspired React UI backed by Flask and MySQL.

## Folder Structure

```text
.
|-- backend
|   |-- app
|   |   |-- routes
|   |   |-- services
|   |   `-- utils
|   |-- .env.example
|   |-- requirements.txt
|   `-- run.py
|-- database
|   |-- schema.sql
|   `-- seed.sql
|-- frontend
|   |-- public
|   |-- src
|   |   |-- api
|   |   |-- components
|   |   |-- context
|   |   |-- hooks
|   |   |-- pages
|   |   `-- styles
|   |-- .env.example
|   `-- package.json
`-- README.md
```

## Features

- React frontend with dark SaaS-style dashboard, smooth hover states, and responsive layout
- User login, register, Google OAuth button integration, and separate admin login
- User dashboard modules for vehicle tracking, package tracking, payment monitoring, FASTag reminders, and route suggestions
- Admin dashboard modules for overview analytics, vehicles, drivers, orders, payments, and alerts
- Polling-based real-time refresh for operational data
- Floating chatbot widget for order, vehicle, and payment questions
- Flask REST API with JWT authentication, CORS, validation, CRUD for vehicles/drivers, order assignment, payments, alerts, route suggestions, and FASTag reminders
- MySQL schema for `users`, `drivers`, `vehicles`, `orders`, and `payments`

## Backend Setup

1. Create a MySQL database and run [schema.sql](</D:/codex app/database/schema.sql>).
2. In [backend](</D:/codex app/backend>), create a virtual environment:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

3. Copy [backend/.env.example](</D:/codex app/backend/.env.example>) to `.env` and update:

```env
DATABASE_URL=mysql+pymysql://root:password@localhost:3306/logistics_tracking
JWT_SECRET_KEY=your-jwt-secret
SECRET_KEY=your-flask-secret
GOOGLE_CLIENT_ID=your-google-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-google-client-secret
```

4. Start the API:

```powershell
flask --app run.py run
```

5. Seed sample data:

```powershell
flask --app run.py seed
```

If you are upgrading from the earlier starter, rerun the seed command after these model changes so the new driver, FASTag, order timeline, and payment fields are recreated.

Sample logins after seeding:

- User: `user@logistics.com` / `User@123`
- Admin: `admin@logistics.com` / `Admin@123`

## Frontend Setup

1. In [frontend](</D:/codex app/frontend>), install packages:

```powershell
npm install
```

2. Copy [frontend/.env.example](</D:/codex app/frontend/.env.example>) to `.env` and update:

```env
VITE_API_BASE_URL=http://127.0.0.1:5000/api
VITE_GOOGLE_CLIENT_ID=your-google-client-id.apps.googleusercontent.com
```

3. Start the React app:

```powershell
npm run dev
```

## API Endpoints

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/google`
- `GET /api/dashboard`
- `GET /api/vehicles`
- `POST /api/vehicles`
- `PUT /api/vehicles/:id`
- `DELETE /api/vehicles/:id`
- `GET /api/vehicle-live-tracking`
- `GET /api/drivers`
- `POST /api/drivers`
- `PUT /api/drivers/:id`
- `DELETE /api/drivers/:id`
- `GET /api/orders`
- `POST /api/orders`
- `PUT /api/orders/:id`
- `GET /api/payments`
- `GET /api/payments/:id/invoice`
- `GET /api/fastag-reminders`
- `POST /api/route-suggestions`
- `GET /api/alerts`
- `GET /api/admin/overview`
- `POST /api/chatbot`

## Notes

- Google OAuth is wired for Google Identity Services and requires a valid OAuth client ID in both apps.
- If `GOOGLE_CLIENT_ID` is missing, the backend returns a graceful configuration error and email/password login still works.
- The backend defaults to SQLite only if `DATABASE_URL` is not set, which is helpful for quick smoke testing. For the requested setup, point it to MySQL.
- `database/seed.sql` contains sample records, but the recommended route is `flask --app run.py seed` because it generates password hashes correctly.
