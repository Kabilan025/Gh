import os

from dotenv import load_dotenv
from flask import Flask

from .extensions import cors, db, jwt
from .routes import (
    admin_bp,
    alerts_bp,
    auth_bp,
    chatbot_bp,
    drivers_bp,
    orders_bp,
    payments_bp,
    tracking_bp,
    utilities_bp,
    vehicles_bp,
)


def create_app():
    load_dotenv()

    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret")
    app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "jwt-secret")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
        "DATABASE_URL", "sqlite:///logistics.db"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["GOOGLE_CLIENT_ID"] = os.getenv("GOOGLE_CLIENT_ID", "")
    app.config["GOOGLE_CLIENT_SECRET"] = os.getenv("GOOGLE_CLIENT_SECRET", "")

    db.init_app(app)
    jwt.init_app(app)
    cors.init_app(
        app,
        resources={r"/api/*": {"origins": os.getenv("FRONTEND_URL", "*")}},
        supports_credentials=False,
    )

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(alerts_bp)
    app.register_blueprint(drivers_bp)
    app.register_blueprint(orders_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(vehicles_bp)
    app.register_blueprint(tracking_bp)
    app.register_blueprint(chatbot_bp)
    app.register_blueprint(utilities_bp)

    @app.get("/api/health")
    def health_check():
        return {"status": "ok", "service": "logistics-tracking-api"}

    with app.app_context():
        db.create_all()

    return app
