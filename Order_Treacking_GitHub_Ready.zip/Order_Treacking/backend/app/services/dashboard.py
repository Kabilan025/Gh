from ..models import Driver, Order, Payment, Vehicle


def count_by_status(records, allowed_statuses):
    counts = {status: 0 for status in allowed_statuses}
    for record in records:
        key = record.status.lower()
        if key in counts:
            counts[key] += 1
    return counts


def build_admin_overview():
    vehicles = Vehicle.query.all()
    orders = Order.query.all()
    payments = Payment.query.all()
    drivers = Driver.query.all()

    return {
        "metrics": {
            "total_vehicles": len(vehicles),
            "active_vehicles": len([vehicle for vehicle in vehicles if vehicle.status.lower() not in ["maintenance", "delivered"]]),
            "total_orders": len(orders),
            "delayed_orders": len([order for order in orders if order.status == "delayed"]),
            "total_revenue": round(sum(float(payment.amount) for payment in payments if payment.status == "paid"), 2),
            "driver_count": len(drivers),
        },
        "charts": {
            "orders": count_by_status(
                orders,
                ["ordered", "packed", "shipped", "out_for_delivery", "delivered", "delayed"],
            ),
            "payments": count_by_status(payments, ["paid", "pending", "failed"]),
        },
    }
