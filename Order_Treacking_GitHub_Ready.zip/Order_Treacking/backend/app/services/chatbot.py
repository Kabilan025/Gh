def build_chatbot_response(message, orders, vehicles, payments):
    prompt = (message or "").lower()
    order = orders[0] if orders else None
    vehicle = vehicles[0] if vehicles else None
    payment = payments[0] if payments else None

    if "where is my order" in prompt or ("order" in prompt and "where" in prompt):
        if order:
            return (
                f"Your order {order['tracking_number']} is {order['status']} with ETA {order['eta']}. "
                f"Assigned vehicle: {order.get('vehicle', {}).get('vehicle_number', 'not assigned yet')}."
            )
        return "I could not find an order assigned to your account right now."

    if "payment" in prompt or "invoice" in prompt or "billing" in prompt:
        if payment:
            return (
                f"Payment {payment['reference']} is {payment['status']} for ${payment['amount']:.2f}. "
                f"You can use the invoice download action from the payment panel."
            )
        return "I could not find a payment record yet."

    if "vehicle" in prompt or "location" in prompt or "driver" in prompt:
        if vehicle:
            return (
                f"Vehicle {vehicle['vehicle_number']} is currently at "
                f"{vehicle['latitude']}, {vehicle['longitude']} on {vehicle['route_details']}. "
                f"ETA is {vehicle.get('current_eta') or 'being updated'}."
            )
        return "Vehicle location is not available right now."

    if "status" in prompt and order:
        return (
            f"Order {order['tracking_number']} is {order['status']}. "
            f"Vehicle ETA is {order['eta']}."
        )

    return (
        "I can help with order status, vehicle location, payment status, and invoice questions. "
        "Try asking: Where is my order, payment status, or vehicle location."
    )
