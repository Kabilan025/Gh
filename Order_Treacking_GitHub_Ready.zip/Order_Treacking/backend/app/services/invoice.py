from datetime import datetime


def build_invoice_pdf(payment):
    lines = [
        "%PDF-1.4",
        "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj",
        "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj",
        "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj",
    ]
    invoice_text = [
        "BT",
        "/F1 18 Tf 50 740 Td (LogiPulse Invoice) Tj",
        "/F1 12 Tf 0 -30 Td " + f"(Reference: {payment.reference}) Tj",
        f"0 -20 Td (Amount: ${float(payment.amount):.2f}) Tj",
        f"0 -20 Td (Status: {payment.status}) Tj",
        f"0 -20 Td (Method: {payment.method}) Tj",
        f"0 -20 Td (Generated: {datetime.utcnow().isoformat(timespec='seconds')} UTC) Tj",
        "ET",
    ]
    stream = "\n".join(invoice_text)
    lines.append(f"4 0 obj << /Length {len(stream)} >> stream\n{stream}\nendstream endobj")
    lines.append("5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj")

    offsets = []
    pdf = ""
    for line in lines:
        offsets.append(len(pdf.encode("utf-8")))
        pdf += line + "\n"

    xref_offset = len(pdf.encode("utf-8"))
    pdf += f"xref\n0 {len(lines) + 1}\n0000000000 65535 f \n"
    for offset in offsets:
        pdf += f"{offset:010d} 00000 n \n"
    pdf += f"trailer << /Size {len(lines) + 1} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF"
    return pdf.encode("utf-8")
