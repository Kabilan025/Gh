from datetime import date
from math import asin, cos, radians, sin, sqrt

CITY_COORDINATES = {
    "mumbai": (19.0760, 72.8777),
    "pune": (18.5204, 73.8567),
    "delhi": (28.6139, 77.2090),
    "jaipur": (26.9124, 75.7873),
    "bangalore": (12.9716, 77.5946),
    "chennai": (13.0827, 80.2707),
    "hyderabad": (17.3850, 78.4867),
    "kolkata": (22.5726, 88.3639),
}


def get_city_coordinates(city_name):
    return CITY_COORDINATES.get((city_name or "").strip().lower(), (20.5937, 78.9629))


def build_vehicle_path(vehicle):
    start = get_city_coordinates(vehicle.source or vehicle.route_details.split("->")[0].strip())
    end = get_city_coordinates(vehicle.destination or vehicle.route_details.split("->")[-1].strip())
    current = (vehicle.latitude, vehicle.longitude)
    return [list(start), [round((start[0] + current[0]) / 2, 4), round((start[1] + current[1]) / 2, 4)], list(current), [round((current[0] + end[0]) / 2, 4), round((current[1] + end[1]) / 2, 4)], list(end)]


def haversine_distance(source, destination):
    lat1, lon1 = get_city_coordinates(source)
    lat2, lon2 = get_city_coordinates(destination)
    radius_km = 6371
    d_lat = radians(lat2 - lat1)
    d_lon = radians(lon2 - lon1)
    a = sin(d_lat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(d_lon / 2) ** 2
    return round(2 * radius_km * asin(sqrt(a)), 1)


def build_route_suggestion(source, destination):
    distance = haversine_distance(source, destination)
    estimated_hours = max(1.5, round(distance / 48, 1))
    corridor = f"{source} freight corridor -> {destination} delivery lane"
    return {
        "source": source,
        "destination": destination,
        "distance_km": distance,
        "estimated_time_hours": estimated_hours,
        "suggested_route": corridor,
        "integration_ready": "Ready for Google Maps Directions API or other routing provider.",
    }


def fastag_reminder_payload(vehicle):
    if not vehicle.fastag_expiry_date:
        return None

    days_remaining = (vehicle.fastag_expiry_date - date.today()).days
    if days_remaining < 0:
        level = "overdue"
        message = f"FASTag expired {-days_remaining} days ago."
    elif days_remaining <= 7:
        level = "upcoming"
        message = f"FASTag expires in {days_remaining} day{'s' if days_remaining != 1 else ''}."
    else:
        return None

    return {
        "vehicle_id": vehicle.id,
        "vehicle_number": vehicle.vehicle_number,
        "route_details": vehicle.route_details,
        "fastag_expiry_date": vehicle.fastag_expiry_date.isoformat(),
        "level": level,
        "message": message,
    }
