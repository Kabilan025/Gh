from datetime import date, datetime, timedelta

from ..extensions import db
from ..models import Driver, Order, Payment, User, Vehicle


def seed_database():
    db.drop_all()
    db.create_all()

    user = User(name="Ava Carter", email="user@logistics.com", role="user")
    user.set_password("User@123")

    admin = User(name="Admin One", email="admin@logistics.com", role="admin")
    admin.set_password("Admin@123")

    driver_1 = Driver(
        name="Ravi Kumar",
        phone="+91-9876543210",
        license_number="LIC-RAVI-001",
        availability="assigned",
    )
    driver_2 = Driver(
        name="Sonia Patel",
        phone="+91-9988776655",
        license_number="LIC-SONIA-002",
        availability="assigned",
    )
    driver_3 = Driver(
        name="Arjun Mehta",
        phone="+91-9090909090",
        license_number="LIC-ARJUN-003",
        availability="unavailable",
    )

    vehicle_1 = Vehicle(
        vehicle_number="MH12AB1234",
        route_details="Mumbai Hub -> Pune DC",
        source="Mumbai",
        destination="Pune",
        latitude=18.5204,
        longitude=73.8567,
        current_eta="Today, 8:30 PM",
        fastag_expiry_date=date.today() + timedelta(days=2),
        status="In Transit",
        driver=driver_1,
    )
    vehicle_2 = Vehicle(
        vehicle_number="DL8CAF7788",
        route_details="Delhi Hub -> Jaipur DC",
        source="Delhi",
        destination="Jaipur",
        latitude=28.6139,
        longitude=77.2090,
        current_eta="Tomorrow, 2:00 PM",
        fastag_expiry_date=date.today() - timedelta(days=1),
        status="Scheduled",
        driver=driver_2,
    )
    vehicle_3 = Vehicle(
        vehicle_number="KA01XY2211",
        route_details="Bangalore Hub -> Chennai DC",
        source="Bangalore",
        destination="Chennai",
        latitude=12.9716,
        longitude=77.5946,
        current_eta="Tomorrow, 11:15 AM",
        fastag_expiry_date=date.today() + timedelta(days=12),
        status="Maintenance",
        driver=None,
    )

    now = datetime.utcnow()

    order_1 = Order(
        tracking_number="ORD-1001",
        customer_name="Ava Carter",
        origin="Mumbai",
        destination="Pune",
        status="shipped",
        eta="Today, 8:30 PM",
        ordered_at=now - timedelta(days=2),
        packed_at=now - timedelta(days=2, hours=-3),
        shipped_at=now - timedelta(days=1),
        user=user,
        vehicle=vehicle_1,
        driver=driver_1,
    )
    order_2 = Order(
        tracking_number="ORD-1002",
        customer_name="Ava Carter",
        origin="Delhi",
        destination="Jaipur",
        status="delayed",
        eta="Tomorrow, 2:00 PM",
        ordered_at=now - timedelta(days=3),
        packed_at=now - timedelta(days=2),
        delayed_at=now - timedelta(hours=5),
        user=user,
        vehicle=vehicle_2,
        driver=driver_2,
    )
    order_3 = Order(
        tracking_number="ORD-1003",
        customer_name="Ava Carter",
        origin="Bangalore",
        destination="Chennai",
        status="out_for_delivery",
        eta="Today, 6:45 PM",
        ordered_at=now - timedelta(days=1, hours=8),
        packed_at=now - timedelta(days=1, hours=4),
        shipped_at=now - timedelta(hours=12),
        out_for_delivery_at=now - timedelta(hours=2),
        user=user,
        vehicle=vehicle_3,
    )

    payment_1 = Payment(
        reference="PAY-5001",
        amount=249.99,
        method="UPI",
        status="paid",
        paid_at=datetime.utcnow(),
        user=user,
        order=order_1,
    )
    payment_2 = Payment(
        reference="PAY-5002",
        amount=149.50,
        method="Card",
        status="pending",
        user=user,
        order=order_2,
    )
    payment_3 = Payment(
        reference="PAY-5003",
        amount=319.00,
        method="Net Banking",
        status="failed",
        user=user,
        order=order_3,
    )

    db.session.add_all(
        [
            user,
            admin,
            driver_1,
            driver_2,
            driver_3,
            vehicle_1,
            vehicle_2,
            vehicle_3,
            order_1,
            order_2,
            order_3,
            payment_1,
            payment_2,
            payment_3,
        ]
    )
    db.session.commit()
