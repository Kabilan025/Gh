from datetime import datetime

from flask import Blueprint, request
from flask_jwt_extended import get_jwt, get_jwt_identity, jwt_required

from ..extensions import db
from ..models import ORDER_STATUSES, Driver, Order, User, Vehicle

orders_bp = Blueprint("orders", __name__, url_prefix="/api/orders")


def _is_admin():
    return get_jwt().get("role") == "admin"


def _apply_status_timestamp(order, status):
    now = datetime.utcnow()
    mapping = {
        "ordered": "ordered_at",
        "packed": "packed_at",
        "shipped": "shipped_at",
        "out_for_delivery": "out_for_delivery_at",
        "delivered": "delivered_at",
        "delayed": "delayed_at",
    }
    field = mapping.get(status)
    if field and getattr(order, field) is None:
        setattr(order, field, now)


@orders_bp.get("")
@jwt_required()
def list_orders():
    user_id = int(get_jwt_identity())
    if _is_admin():
        orders = Order.query.order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
    return {"orders": [order.to_dict() for order in orders]}


@orders_bp.post("")
@jwt_required()
def create_order():
    if not _is_admin():
        return {"message": "Admin access required."}, 403

    data = request.get_json() or {}
    required = ["tracking_number", "customer_name", "origin", "destination", "user_id"]
    if any(not str(data.get(field, "")).strip() for field in required):
        return {"message": "Missing required order fields."}, 400
    if Order.query.filter_by(tracking_number=data["tracking_number"]).first():
        return {"message": "Tracking number already exists."}, 409

    user = User.query.get_or_404(int(data["user_id"]))
    order = Order(
        tracking_number=data["tracking_number"],
        customer_name=data["customer_name"],
        origin=data["origin"],
        destination=data["destination"],
        status=data.get("status", "ordered"),
        eta=data.get("eta"),
        user=user,
        vehicle_id=data.get("vehicle_id"),
        driver_id=data.get("driver_id"),
    )
    if order.driver:
        order.driver.availability = "assigned"
    _apply_status_timestamp(order, order.status)
    db.session.add(order)
    db.session.commit()
    return {"order": order.to_dict()}, 201


@orders_bp.put("/<int:order_id>")
@jwt_required()
def update_order(order_id):
    if not _is_admin():
        return {"message": "Admin access required."}, 403

    order = Order.query.get_or_404(order_id)
    data = request.get_json() or {}

    for field in ["customer_name", "origin", "destination", "eta"]:
        if field in data:
            setattr(order, field, data[field])

    if "status" in data:
        if data["status"] not in ORDER_STATUSES:
            return {"message": "Invalid order status."}, 400
        order.status = data["status"]
        _apply_status_timestamp(order, order.status)

    if "vehicle_id" in data:
        vehicle_id = data.get("vehicle_id")
        order.vehicle = Vehicle.query.get(vehicle_id) if vehicle_id else None
    if "driver_id" in data:
        driver_id = data.get("driver_id")
        order.driver = Driver.query.get(driver_id) if driver_id else None
        if order.driver:
            order.driver.availability = "assigned"

    db.session.commit()
    return {"order": order.to_dict()}
