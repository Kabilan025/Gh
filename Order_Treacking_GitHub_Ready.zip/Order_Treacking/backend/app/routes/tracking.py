from flask import Blueprint
from flask_jwt_extended import get_jwt_identity, jwt_required

from ..models import Order, Payment, User, Vehicle
from ..services.logistics import build_vehicle_path, fastag_reminder_payload

tracking_bp = Blueprint("tracking", __name__, url_prefix="/api")


@tracking_bp.get("/dashboard")
@jwt_required()
def dashboard():
    user_id = int(get_jwt_identity())
    user = User.query.get_or_404(user_id)

    if user.role == "admin":
        orders = Order.query.order_by(Order.created_at.desc()).all()
        payments = Payment.query.order_by(Payment.created_at.desc()).all()
    else:
        orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
        payments = (
            Payment.query.filter_by(user_id=user_id).order_by(Payment.created_at.desc()).all()
        )

    vehicles = Vehicle.query.order_by(Vehicle.created_at.desc()).all()

    order_status_counts = {
        "ordered": 0,
        "packed": 0,
        "shipped": 0,
        "out_for_delivery": 0,
        "delivered": 0,
        "delayed": 0,
    }
    for order in orders:
        key = order.status.lower()
        if key in order_status_counts:
            order_status_counts[key] += 1

    payment_status_counts = {"paid": 0, "pending": 0, "failed": 0}
    for payment in payments:
        key = payment.status.lower()
        if key in payment_status_counts:
            payment_status_counts[key] += 1

    return {
        "vehicles": [
            {
                **vehicle.to_dict(),
                "path": build_vehicle_path(vehicle),
            }
            for vehicle in vehicles
        ],
        "orders": [order.to_dict() for order in orders],
        "payments": [payment.to_dict() for payment in payments],
        "metrics": {
            "vehicle_count": len(vehicles),
            "active_orders": len(orders),
            "payment_volume": round(sum(float(payment.amount) for payment in payments), 2),
            "pending_payments": round(
                sum(float(payment.amount) for payment in payments if payment.status == "pending"),
                2,
            ),
        },
        "charts": {
            "order_status_counts": order_status_counts,
            "payment_status_counts": payment_status_counts,
        },
        "fastag_reminders": [
            reminder
            for reminder in (fastag_reminder_payload(vehicle) for vehicle in vehicles)
            if reminder
        ],
    }
