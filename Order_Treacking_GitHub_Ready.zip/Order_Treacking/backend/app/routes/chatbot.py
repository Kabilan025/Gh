from flask import Blueprint, request
from flask_jwt_extended import get_jwt_identity, jwt_required

from ..models import Order, Payment, User, Vehicle
from ..services.chatbot import build_chatbot_response

chatbot_bp = Blueprint("chatbot", __name__, url_prefix="/api/chatbot")


@chatbot_bp.post("")
@jwt_required()
def chatbot():
    user_id = int(get_jwt_identity())
    user = User.query.get_or_404(user_id)
    payload = request.get_json() or {}
    message = payload.get("message", "")

    if user.role == "admin":
        orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
        payments = Payment.query.order_by(Payment.created_at.desc()).limit(5).all()
    else:
        orders = Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).limit(5).all()
        payments = Payment.query.filter_by(user_id=user.id).order_by(Payment.created_at.desc()).limit(5).all()
    vehicles = Vehicle.query.order_by(Vehicle.created_at.desc()).limit(5).all()

    reply = build_chatbot_response(
        message,
        [order.to_dict() for order in orders],
        [vehicle.to_dict() for vehicle in vehicles],
        [payment.to_dict() for payment in payments],
    )
    return {"reply": reply}
