from flask import Blueprint, request
from flask_jwt_extended import get_jwt, jwt_required

from ..extensions import db
from ..models import DRIVER_AVAILABILITY, Driver

drivers_bp = Blueprint("drivers", __name__, url_prefix="/api/drivers")


def _ensure_admin():
    return get_jwt().get("role") == "admin"


@drivers_bp.get("")
@jwt_required()
def list_drivers():
    drivers = Driver.query.order_by(Driver.created_at.desc()).all()
    return {"drivers": [driver.to_dict() for driver in drivers]}


@drivers_bp.post("")
@jwt_required()
def create_driver():
    if not _ensure_admin():
        return {"message": "Admin access required."}, 403

    data = request.get_json() or {}
    required = ["name", "phone", "license_number", "availability"]
    if any(not str(data.get(field, "")).strip() for field in required):
        return {"message": "All driver fields are required."}, 400
    if data["availability"] not in DRIVER_AVAILABILITY:
        return {"message": "Invalid driver availability."}, 400
    if Driver.query.filter_by(license_number=data["license_number"]).first():
        return {"message": "License number already exists."}, 409

    driver = Driver(
        name=data["name"],
        phone=data["phone"],
        license_number=data["license_number"],
        availability=data["availability"],
    )
    db.session.add(driver)
    db.session.commit()
    return {"driver": driver.to_dict()}, 201


@drivers_bp.put("/<int:driver_id>")
@jwt_required()
def update_driver(driver_id):
    if not _ensure_admin():
        return {"message": "Admin access required."}, 403

    driver = Driver.query.get_or_404(driver_id)
    data = request.get_json() or {}
    for field in ["name", "phone", "license_number", "availability"]:
        if field in data and data[field]:
            setattr(driver, field, data[field])
    db.session.commit()
    return {"driver": driver.to_dict()}


@drivers_bp.delete("/<int:driver_id>")
@jwt_required()
def delete_driver(driver_id):
    if not _ensure_admin():
        return {"message": "Admin access required."}, 403

    driver = Driver.query.get_or_404(driver_id)
    for vehicle in driver.vehicles:
        vehicle.driver = None
    for order in driver.orders:
        order.driver = None
    db.session.delete(driver)
    db.session.commit()
    return {"message": "Driver deleted successfully."}
