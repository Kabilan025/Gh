from flask import Blueprint
from flask_jwt_extended import get_jwt, jwt_required

from ..services.dashboard import build_admin_overview

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")


@admin_bp.get("/overview")
@jwt_required()
def admin_overview():
    if get_jwt().get("role") != "admin":
        return {"message": "Admin access required."}, 403
    return build_admin_overview()
