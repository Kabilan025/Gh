from flask import Blueprint, Response, request
from flask_jwt_extended import get_jwt, get_jwt_identity, jwt_required

from ..models import Payment
from ..services.invoice import build_invoice_pdf

payments_bp = Blueprint("payments", __name__, url_prefix="/api/payments")


@payments_bp.get("")
@jwt_required()
def list_payments():
    status = request.args.get("status")
    query = Payment.query.order_by(Payment.created_at.desc())
    if get_jwt().get("role") != "admin":
        query = query.filter_by(user_id=int(get_jwt_identity()))
    if status:
        query = query.filter_by(status=status)
    payments = query.all()

    total_amount = round(sum(float(payment.amount) for payment in payments), 2)
    pending_amount = round(
        sum(float(payment.amount) for payment in payments if payment.status == "pending"), 2
    )

    return {
        "payments": [payment.to_dict() for payment in payments],
        "summary": {
            "total_payments": total_amount,
            "pending_payments": pending_amount,
        },
    }


@payments_bp.get("/<int:payment_id>/invoice")
@jwt_required()
def download_invoice(payment_id):
    payment = Payment.query.get_or_404(payment_id)
    if get_jwt().get("role") != "admin" and payment.user_id != int(get_jwt_identity()):
        return {"message": "Access denied."}, 403
    pdf_content = build_invoice_pdf(payment)
    return Response(
        pdf_content,
        mimetype="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="invoice-{payment.reference}.pdf"'
        },
    )
