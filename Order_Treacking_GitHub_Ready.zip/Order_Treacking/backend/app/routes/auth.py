from flask import Blueprint, current_app, request
from flask_jwt_extended import create_access_token
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token

from ..extensions import db
from ..models import User

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


def _issue_auth_response(user):
    token = create_access_token(
        identity=str(user.id),
        additional_claims={"role": user.role, "email": user.email},
    )
    return {"token": token, "user": user.to_dict()}


@auth_bp.post("/register")
def register():
    data = request.get_json() or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    role = data.get("role", "user")

    if not name or not email or not password:
        return {"message": "Name, email, and password are required."}, 400

    if User.query.filter_by(email=email).first():
        return {"message": "An account with this email already exists."}, 409

    user = User(name=name, email=email, role=role)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    return _issue_auth_response(user), 201


@auth_bp.post("/login")
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    requested_role = data.get("role", "user")

    user = User.query.filter_by(email=email, role=requested_role).first()
    if not user or not user.check_password(password):
        return {"message": "Invalid credentials."}, 401

    return _issue_auth_response(user)


@auth_bp.post("/google")
def google_login():
    data = request.get_json() or {}
    credential = data.get("credential")
    if not credential:
        return {"message": "Google credential token is required."}, 400
    if not current_app.config["GOOGLE_CLIENT_ID"]:
        return {
            "message": "Google OAuth is not configured. Use email/password login or add GOOGLE_CLIENT_ID."
        }, 503

    try:
        token_info = id_token.verify_oauth2_token(
            credential,
            google_requests.Request(),
            current_app.config["GOOGLE_CLIENT_ID"],
        )
    except Exception:
        return {"message": "Google authentication failed."}, 401

    email = token_info.get("email", "").lower()
    name = token_info.get("name", "Google User")
    sub = token_info.get("sub")

    if not email or not sub:
        return {"message": "Google profile data is incomplete."}, 400

    user = User.query.filter((User.email == email) | (User.google_sub == sub)).first()
    if not user:
        user = User(name=name, email=email, role="user", google_sub=sub)
        db.session.add(user)
    else:
        user.google_sub = sub
        user.name = name

    db.session.commit()
    return _issue_auth_response(user)
