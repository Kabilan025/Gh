from datetime import datetime

from flask import Blueprint, request
from flask_jwt_extended import get_jwt, jwt_required

from ..extensions import db
from ..models import Driver, Vehicle

vehicles_bp = Blueprint("vehicles", __name__, url_prefix="/api/vehicles")


def _admin_only():
    return get_jwt().get("role") == "admin"


@vehicles_bp.get("")
@jwt_required()
def list_vehicles():
    vehicles = Vehicle.query.order_by(Vehicle.created_at.desc()).all()
    return {"vehicles": [vehicle.to_dict() for vehicle in vehicles]}


@vehicles_bp.post("")
@jwt_required()
def create_vehicle():
    if not _admin_only():
        return {"message": "Admin access required."}, 403

    data = request.get_json() or {}
    required_fields = [
        "vehicle_number",
        "route_details",
        "latitude",
        "longitude",
    ]
    if any(not str(data.get(field, "")).strip() for field in required_fields):
        return {"message": "All vehicle fields are required."}, 400

    if Vehicle.query.filter_by(vehicle_number=data["vehicle_number"]).first():
        return {"message": "Vehicle number already exists."}, 409

    driver = None
    if data.get("driver_id"):
        driver = Driver.query.get(int(data["driver_id"]))
    elif data.get("driver_name") and data.get("driver_phone") and data.get("license_number"):
        driver = Driver(
            name=data["driver_name"],
            phone=data["driver_phone"],
            license_number=data["license_number"],
            availability="assigned",
        )
        db.session.add(driver)

    vehicle = Vehicle(
        vehicle_number=data["vehicle_number"],
        route_details=data["route_details"],
        source=data.get("source"),
        destination=data.get("destination"),
        latitude=float(data["latitude"]),
        longitude=float(data["longitude"]),
        current_eta=data.get("current_eta"),
        fastag_expiry_date=datetime.fromisoformat(data["fastag_expiry_date"]).date()
        if data.get("fastag_expiry_date")
        else None,
        status=data.get("status", "In Transit"),
        driver=driver,
    )
    if driver:
        driver.availability = "assigned"
    db.session.add(vehicle)
    db.session.commit()
    return {"vehicle": vehicle.to_dict()}, 201


@vehicles_bp.put("/<int:vehicle_id>")
@jwt_required()
def update_vehicle(vehicle_id):
    if not _admin_only():
        return {"message": "Admin access required."}, 403

    vehicle = Vehicle.query.get_or_404(vehicle_id)
    data = request.get_json() or {}

    vehicle.vehicle_number = data.get("vehicle_number", vehicle.vehicle_number)
    vehicle.route_details = data.get("route_details", vehicle.route_details)
    vehicle.source = data.get("source", vehicle.source)
    vehicle.destination = data.get("destination", vehicle.destination)
    vehicle.latitude = float(data.get("latitude", vehicle.latitude))
    vehicle.longitude = float(data.get("longitude", vehicle.longitude))
    vehicle.current_eta = data.get("current_eta", vehicle.current_eta)
    if "fastag_expiry_date" in data:
        vehicle.fastag_expiry_date = (
            datetime.fromisoformat(data["fastag_expiry_date"]).date()
            if data["fastag_expiry_date"]
            else None
        )
    vehicle.status = data.get("status", vehicle.status)

    if "driver_id" in data:
        driver = Driver.query.get(data["driver_id"]) if data["driver_id"] else None
        vehicle.driver = driver
        if driver:
            driver.availability = "assigned"

    db.session.commit()
    return {"vehicle": vehicle.to_dict()}


@vehicles_bp.delete("/<int:vehicle_id>")
@jwt_required()
def delete_vehicle(vehicle_id):
    if not _admin_only():
        return {"message": "Admin access required."}, 403

    vehicle = Vehicle.query.get_or_404(vehicle_id)
    if vehicle.driver:
        vehicle.driver.availability = "available"
    db.session.delete(vehicle)
    db.session.commit()
    return {"message": "Vehicle deleted successfully."}
