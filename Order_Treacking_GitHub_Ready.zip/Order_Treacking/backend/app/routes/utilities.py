from flask import Blueprint, request
from flask_jwt_extended import jwt_required

from ..models import Vehicle
from ..services.logistics import (
    build_route_suggestion,
    build_vehicle_path,
    fastag_reminder_payload,
)

utilities_bp = Blueprint("utilities", __name__, url_prefix="/api")


@utilities_bp.get("/fastag-reminders")
@jwt_required()
def fastag_reminders():
    reminders = [
        fastag_reminder_payload(vehicle) for vehicle in Vehicle.query.order_by(Vehicle.created_at.desc()).all()
    ]
    return {"reminders": [reminder for reminder in reminders if reminder]}


@utilities_bp.post("/route-suggestions")
@jwt_required()
def route_suggestions():
    payload = request.get_json() or {}
    source = payload.get("source", "")
    destination = payload.get("destination", "")
    if not source or not destination:
        return {"message": "Source and destination are required."}, 400
    return {"suggestion": build_route_suggestion(source, destination)}


@utilities_bp.get("/vehicle-live-tracking")
@jwt_required()
def vehicle_live_tracking():
    vehicles = Vehicle.query.order_by(Vehicle.created_at.desc()).all()
    tracking_data = []
    for vehicle in vehicles:
        payload = vehicle.to_dict()
        payload["path"] = build_vehicle_path(vehicle)
        tracking_data.append(payload)
    return {"vehicles": tracking_data}
