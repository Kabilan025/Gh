from .admin import admin_bp
from .alerts import alerts_bp
from .auth import auth_bp
from .chatbot import chatbot_bp
from .drivers import drivers_bp
from .orders import orders_bp
from .payments import payments_bp
from .tracking import tracking_bp
from .utilities import utilities_bp
from .vehicles import vehicles_bp

__all__ = [
    "admin_bp",
    "alerts_bp",
    "auth_bp",
    "chatbot_bp",
    "drivers_bp",
    "orders_bp",
    "payments_bp",
    "tracking_bp",
    "utilities_bp",
    "vehicles_bp",
]
