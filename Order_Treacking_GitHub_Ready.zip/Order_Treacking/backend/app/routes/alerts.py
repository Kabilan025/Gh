from flask import Blueprint
from flask_jwt_extended import get_jwt, jwt_required

from ..models import Driver, Order, Payment, Vehicle

alerts_bp = Blueprint("alerts", __name__, url_prefix="/api/alerts")


@alerts_bp.get("")
@jwt_required()
def alerts():
    if get_jwt().get("role") != "admin":
        return {"message": "Admin access required."}, 403

    delayed_orders = [
        {"type": "delayed_order", "message": f"{order.tracking_number} is delayed."}
        for order in Order.query.filter_by(status="delayed").all()
    ]
    unassigned_vehicles = [
        {"type": "unassigned_vehicle", "message": f"{vehicle.vehicle_number} has no driver assigned."}
        for vehicle in Vehicle.query.filter_by(driver_id=None).all()
    ]
    unavailable_drivers = [
        {"type": "driver_unavailable", "message": f"{driver.name} is marked unavailable."}
        for driver in Driver.query.filter_by(availability="unavailable").all()
    ]
    failed_payments = [
        {"type": "failed_payment", "message": f"{payment.reference} failed for ${float(payment.amount):.2f}."}
        for payment in Payment.query.filter_by(status="failed").all()
    ]

    return {"alerts": delayed_orders + unassigned_vehicles + unavailable_drivers + failed_payments}
