from datetime import datetime

from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db

ORDER_STATUSES = [
    "ordered",
    "packed",
    "shipped",
    "out_for_delivery",
    "delivered",
    "delayed",
]
PAYMENT_STATUSES = ["paid", "pending", "failed"]
DRIVER_AVAILABILITY = ["available", "assigned", "unavailable"]


class TimestampMixin:
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )


class User(TimestampMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=True)
    role = db.Column(db.String(20), default="user", nullable=False)
    google_sub = db.Column(db.String(255), unique=True, nullable=True)

    orders = db.relationship("Order", back_populates="user", cascade="all, delete-orphan")
    payments = db.relationship(
        "Payment", back_populates="user", cascade="all, delete-orphan"
    )

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "role": self.role,
        }


class Driver(TimestampMixin, db.Model):
    __tablename__ = "drivers"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    license_number = db.Column(db.String(50), unique=True, nullable=False)
    availability = db.Column(db.String(20), default="available", nullable=False)

    vehicles = db.relationship("Vehicle", back_populates="driver")
    orders = db.relationship("Order", back_populates="driver")

    def to_dict(self):
        active_vehicle = next(
            (vehicle for vehicle in self.vehicles if vehicle.status != "Maintenance"), None
        )
        return {
            "id": self.id,
            "name": self.name,
            "phone": self.phone,
            "license_number": self.license_number,
            "availability": self.availability,
            "assigned_vehicle_id": active_vehicle.id if active_vehicle else None,
            "assigned_vehicle_number": active_vehicle.vehicle_number if active_vehicle else None,
        }


class Vehicle(TimestampMixin, db.Model):
    __tablename__ = "vehicles"

    id = db.Column(db.Integer, primary_key=True)
    vehicle_number = db.Column(db.String(50), unique=True, nullable=False)
    route_details = db.Column(db.String(255), nullable=False)
    source = db.Column(db.String(120), nullable=True)
    destination = db.Column(db.String(120), nullable=True)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    current_eta = db.Column(db.String(80), nullable=True)
    fastag_expiry_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(50), default="In Transit", nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=True)

    driver = db.relationship("Driver", back_populates="vehicles")
    orders = db.relationship("Order", back_populates="vehicle")

    def to_dict(self):
        return {
            "id": self.id,
            "vehicle_number": self.vehicle_number,
            "route_details": self.route_details,
            "source": self.source,
            "destination": self.destination,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "current_eta": self.current_eta,
            "fastag_expiry_date": self.fastag_expiry_date.isoformat()
            if self.fastag_expiry_date
            else None,
            "status": self.status,
            "driver": self.driver.to_dict() if self.driver else None,
        }


class Order(TimestampMixin, db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    tracking_number = db.Column(db.String(50), unique=True, nullable=False)
    customer_name = db.Column(db.String(120), nullable=False)
    origin = db.Column(db.String(120), nullable=False)
    destination = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(50), default="ordered", nullable=False)
    eta = db.Column(db.String(80), nullable=True)
    ordered_at = db.Column(db.DateTime, nullable=True)
    packed_at = db.Column(db.DateTime, nullable=True)
    shipped_at = db.Column(db.DateTime, nullable=True)
    out_for_delivery_at = db.Column(db.DateTime, nullable=True)
    delivered_at = db.Column(db.DateTime, nullable=True)
    delayed_at = db.Column(db.DateTime, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    vehicle_id = db.Column(db.Integer, db.ForeignKey("vehicles.id"), nullable=True)
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=True)

    user = db.relationship("User", back_populates="orders")
    vehicle = db.relationship("Vehicle", back_populates="orders")
    driver = db.relationship("Driver", back_populates="orders")
    payments = db.relationship("Payment", back_populates="order")

    def build_timeline(self):
        mapping = [
            ("ordered", self.ordered_at),
            ("packed", self.packed_at),
            ("shipped", self.shipped_at),
            ("out_for_delivery", self.out_for_delivery_at),
            ("delivered", self.delivered_at),
            ("delayed", self.delayed_at),
        ]
        return [
            {
                "status": status,
                "timestamp": timestamp.isoformat() if timestamp else None,
                "completed": timestamp is not None or self.status == status,
            }
            for status, timestamp in mapping
        ]

    def to_dict(self):
        return {
            "id": self.id,
            "tracking_number": self.tracking_number,
            "customer_name": self.customer_name,
            "origin": self.origin,
            "destination": self.destination,
            "status": self.status,
            "eta": self.eta,
            "timeline": self.build_timeline(),
            "vehicle": self.vehicle.to_dict() if self.vehicle else None,
            "driver": self.driver.to_dict() if self.driver else None,
        }


class Payment(TimestampMixin, db.Model):
    __tablename__ = "payments"

    id = db.Column(db.Integer, primary_key=True)
    reference = db.Column(db.String(50), unique=True, nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    method = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(50), default="pending", nullable=False)
    paid_at = db.Column(db.DateTime, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)

    user = db.relationship("User", back_populates="payments")
    order = db.relationship("Order", back_populates="payments")

    def to_dict(self):
        return {
            "id": self.id,
            "reference": self.reference,
            "amount": float(self.amount),
            "method": self.method,
            "status": self.status,
            "paid_at": self.paid_at.isoformat() if self.paid_at else None,
            "invoice_download_url": f"/api/payments/{self.id}/invoice",
            "order": {
                "id": self.order.id,
                "tracking_number": self.order.tracking_number,
            }
            if self.order
            else None,
        }
