from app import create_app
from app.utils.seed import seed_database

app = create_app()


@app.cli.command("seed")
def seed():
    """Seed the database with sample logistics data."""
    seed_database()


if __name__ == "__main__":
    app.run(debug=True)
