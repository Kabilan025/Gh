import { AlertCircle } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginUser } from "../api/auth";
import { useAuth } from "../context/AuthContext";

export default function AdminLoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const data = await loginUser({ ...form, role: "admin" });
      login(data);
      navigate("/admin/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Admin login failed.");
    }
  };

  return (
    <div className="auth-shell admin-shell">
      <div className="auth-panel glass-panel">
        <span className="eyebrow">Secure Operations Center</span>
        <h1>Admin Login</h1>
        <form className="auth-form" onSubmit={handleSubmit}>
          <input
            name="email"
            type="email"
            placeholder="Admin email"
            value={form.email}
            onChange={(event) => setForm({ ...form, email: event.target.value })}
          />
          <input
            name="password"
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={(event) => setForm({ ...form, password: event.target.value })}
          />
          {error && (
            <div className="error-banner">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}
          <button type="submit" className="primary-button">
            Enter Admin Panel
          </button>
        </form>
        <div className="auth-links">
          <Link to="/login">User login</Link>
        </div>
      </div>
    </div>
  );
}
