import {
  AlertTriangle,
  CreditCard,
  LayoutDashboard,
  Pencil,
  Plus,
  Route,
  Trash2,
  Truck,
  UserCog,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  createDriver,
  createVehicle,
  deleteDriver,
  deleteVehicle,
  fetchAdminOverview,
  fetchAlerts,
  fetchDrivers,
  fetchOrders,
  fetchPayments,
  fetchVehicles,
  updateDriver,
  updateOrder,
  updateVehicle,
} from "../api/logistics";
import StatCard from "../components/dashboard/StatCard";
import Navbar from "../components/layout/Navbar";

const initialForm = {
  vehicle_number: "",
  driver_name: "",
  driver_phone: "",
  license_number: "",
  driver_id: "",
  route_details: "",
  source: "",
  destination: "",
  latitude: "",
  longitude: "",
  current_eta: "",
  fastag_expiry_date: "",
  status: "In Transit",
};

const initialDriverForm = {
  name: "",
  phone: "",
  license_number: "",
  availability: "available",
};

const adminTabs = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "vehicles", label: "Vehicles", icon: Truck },
  { id: "drivers", label: "Drivers", icon: UserCog },
  { id: "orders", label: "Orders", icon: Route },
  { id: "payments", label: "Payments", icon: CreditCard },
  { id: "alerts", label: "Alerts", icon: AlertTriangle },
];
const orderStatusOptions = [
  "ordered",
  "packed",
  "shipped",
  "out_for_delivery",
  "delivered",
  "delayed",
];
const chartColors = ["#38bdf8", "#8b5cf6", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4"];

export default function AdminDashboardPage() {
  const [tab, setTab] = useState("overview");
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [payments, setPayments] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [overview, setOverview] = useState({ metrics: {}, charts: { orders: {}, payments: {} } });
  const [form, setForm] = useState(initialForm);
  const [driverForm, setDriverForm] = useState(initialDriverForm);
  const [editingId, setEditingId] = useState(null);
  const [editingDriverId, setEditingDriverId] = useState(null);
  const [paymentFilter, setPaymentFilter] = useState("");
  const [error, setError] = useState("");

  const loadAdminData = useCallback(async () => {
    try {
      const [vehicleData, driverData, orderData, paymentData, alertData, overviewData] =
        await Promise.all([
          fetchVehicles(),
          fetchDrivers(),
          fetchOrders(),
          fetchPayments(paymentFilter),
          fetchAlerts(),
          fetchAdminOverview(),
        ]);
      setVehicles(vehicleData);
      setDrivers(driverData);
      setOrders(orderData);
      setPayments(paymentData.payments);
      setAlerts(alertData);
      setOverview(overviewData);
    } catch (err) {
      setError("Unable to load admin dashboard data.");
    }
  }, [paymentFilter]);

  useEffect(() => {
    loadAdminData();
  }, [loadAdminData]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      if (editingId) {
        await updateVehicle(editingId, form);
      } else {
        await createVehicle(form);
      }
      setForm(initialForm);
      setEditingId(null);
      setError("");
      loadAdminData();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to save vehicle.");
    }
  };

  const handleEdit = (vehicle) => {
    setEditingId(vehicle.id);
    setForm({
      vehicle_number: vehicle.vehicle_number,
      driver_name: "",
      driver_phone: "",
      license_number: "",
      driver_id: vehicle.driver?.id || "",
      route_details: vehicle.route_details,
      source: vehicle.source || "",
      destination: vehicle.destination || "",
      latitude: vehicle.latitude,
      longitude: vehicle.longitude,
      current_eta: vehicle.current_eta || "",
      fastag_expiry_date: vehicle.fastag_expiry_date || "",
      status: vehicle.status,
    });
  };

  const handleDelete = async (id) => {
    try {
      await deleteVehicle(id);
      loadAdminData();
    } catch (err) {
      setError("Unable to delete vehicle.");
    }
  };

  const handleDriverSubmit = async (event) => {
    event.preventDefault();
    try {
      if (editingDriverId) {
        await updateDriver(editingDriverId, driverForm);
      } else {
        await createDriver(driverForm);
      }
      setDriverForm(initialDriverForm);
      setEditingDriverId(null);
      loadAdminData();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to save driver.");
    }
  };

  const handleDriverEdit = (driver) => {
    setEditingDriverId(driver.id);
    setDriverForm({
      name: driver.name,
      phone: driver.phone,
      license_number: driver.license_number,
      availability: driver.availability,
    });
  };

  const handleDriverDelete = async (id) => {
    try {
      await deleteDriver(id);
      loadAdminData();
    } catch (err) {
      setError("Unable to delete driver.");
    }
  };

  const handleOrderUpdate = async (orderId, payload) => {
    try {
      await updateOrder(orderId, payload);
      loadAdminData();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to update order.");
    }
  };

  const orderChartData = Object.entries(overview.charts.orders || {}).map(([name, value]) => ({
    name,
    value,
  }));
  const paymentChartData = Object.entries(overview.charts.payments || {}).map(([name, value]) => ({
    name,
    value,
  }));

  return (
    <div className="page-shell">
      <Navbar title="Admin control center" admin />
      <main className="dashboard-layout">
        <section className="admin-tab-row glass-panel">
          {adminTabs.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                className={`sidebar-link admin-tab ${tab === item.id ? "active" : ""}`}
                onClick={() => setTab(item.id)}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </section>

        {error ? <div className="error-banner">{error}</div> : null}

        {tab === "overview" ? (
          <div className="section-stack">
            <section className="stats-grid">
              <StatCard
                title="Total Vehicles"
                value={overview.metrics.total_vehicles || 0}
                subtitle="registered in the fleet"
                accent="accent-blue"
              />
              <StatCard
                title="Active Vehicles"
                value={overview.metrics.active_vehicles || 0}
                subtitle="currently operational"
                accent="accent-violet"
              />
              <StatCard
                title="Total Orders"
                value={overview.metrics.total_orders || 0}
                subtitle="being managed now"
                accent="accent-green"
              />
            </section>
            <section className="stats-grid">
              <StatCard
                title="Delayed Orders"
                value={overview.metrics.delayed_orders || 0}
                subtitle="need immediate attention"
                accent="accent-violet"
              />
              <StatCard
                title="Total Revenue"
                value={`$${overview.metrics.total_revenue || 0}`}
                subtitle="paid transactions only"
                accent="accent-green"
              />
              <StatCard
                title="Drivers"
                value={overview.metrics.driver_count || 0}
                subtitle="managed in the system"
                accent="accent-blue"
              />
            </section>
            <section className="hero-grid">
              <div className="hero-card glass-panel">
                <div className="section-heading">
                  <div>
                    <h2>Order Status Chart</h2>
                    <p>Distribution of current order workflow states.</p>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={orderChartData}>
                    <XAxis dataKey="name" stroke="#9fb0ff" />
                    <YAxis stroke="#9fb0ff" />
                    <Tooltip />
                    <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                      {orderChartData.map((entry, index) => (
                        <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="hero-card glass-panel">
                <div className="section-heading">
                  <div>
                    <h2>Payment Status Chart</h2>
                    <p>Paid, pending, and failed transaction mix.</p>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={paymentChartData} dataKey="value" nameKey="name" outerRadius={90}>
                      {paymentChartData.map((entry, index) => (
                        <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </section>
          </div>
        ) : null}

        {tab === "vehicles" ? (
          <div className="admin-layout">
            <section className="admin-form-panel glass-panel">
              <div className="section-heading">
                <div>
                  <h2>{editingId ? "Update Vehicle" : "Add New Vehicle"}</h2>
                  <p>Create and manage live fleet records.</p>
                </div>
              </div>
              <form className="vehicle-form" onSubmit={handleSubmit}>
                <input
                  placeholder="Vehicle number"
                  value={form.vehicle_number}
                  onChange={(event) => setForm({ ...form, vehicle_number: event.target.value })}
                />
                <select
                  value={form.driver_id}
                  onChange={(event) => setForm({ ...form, driver_id: event.target.value })}
                >
                  <option value="">Assign driver later</option>
                  {drivers.map((driver) => (
                    <option key={driver.id} value={driver.id}>
                      {driver.name}
                    </option>
                  ))}
                </select>
                <input
                  placeholder="Route details"
                  value={form.route_details}
                  onChange={(event) => setForm({ ...form, route_details: event.target.value })}
                />
                <input
                  placeholder="Source"
                  value={form.source}
                  onChange={(event) => setForm({ ...form, source: event.target.value })}
                />
                <input
                  placeholder="Destination"
                  value={form.destination}
                  onChange={(event) => setForm({ ...form, destination: event.target.value })}
                />
                <input
                  placeholder="Latitude"
                  value={form.latitude}
                  onChange={(event) => setForm({ ...form, latitude: event.target.value })}
                />
                <input
                  placeholder="Longitude"
                  value={form.longitude}
                  onChange={(event) => setForm({ ...form, longitude: event.target.value })}
                />
                <input
                  placeholder="Current ETA"
                  value={form.current_eta}
                  onChange={(event) => setForm({ ...form, current_eta: event.target.value })}
                />
                <input
                  type="date"
                  value={form.fastag_expiry_date}
                  onChange={(event) =>
                    setForm({ ...form, fastag_expiry_date: event.target.value })
                  }
                />
                <select
                  value={form.status}
                  onChange={(event) => setForm({ ...form, status: event.target.value })}
                >
                  <option>In Transit</option>
                  <option>Scheduled</option>
                  <option>Delivered</option>
                  <option>Maintenance</option>
                </select>
                <button type="submit" className="primary-button">
                  <Plus size={16} />
                  {editingId ? "Update Vehicle" : "Add Vehicle"}
                </button>
              </form>
            </section>

            <section className="glass-panel module-card">
              <div className="section-heading">
                <div>
                  <h2>Fleet Inventory</h2>
                  <p>Manage all active vehicle records and coordinates.</p>
                </div>
              </div>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Vehicle</th>
                      <th>Driver</th>
                      <th>Route</th>
                      <th>Status</th>
                      <th>ETA</th>
                      <th>FASTag</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vehicles.map((vehicle) => (
                      <tr key={vehicle.id}>
                        <td>{vehicle.vehicle_number}</td>
                        <td>{vehicle.driver?.name || "Unassigned"}</td>
                        <td>{vehicle.route_details}</td>
                        <td>{vehicle.status}</td>
                        <td>{vehicle.current_eta || "Updating"}</td>
                        <td>{vehicle.fastag_expiry_date || "Not set"}</td>
                        <td className="actions-cell">
                          <button
                            type="button"
                            className="ghost-button"
                            onClick={() => handleEdit(vehicle)}
                          >
                            <Pencil size={14} />
                          </button>
                          <button
                            type="button"
                            className="ghost-button danger"
                            onClick={() => handleDelete(vehicle.id)}
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        ) : null}

        {tab === "drivers" ? (
          <div className="admin-layout">
            <section className="admin-form-panel glass-panel">
              <div className="section-heading">
                <div>
                  <h2>{editingDriverId ? "Update Driver" : "Add Driver"}</h2>
                  <p>Manage driver roster, availability, and assignments.</p>
                </div>
              </div>
              <form className="vehicle-form" onSubmit={handleDriverSubmit}>
                <input
                  placeholder="Driver name"
                  value={driverForm.name}
                  onChange={(event) => setDriverForm({ ...driverForm, name: event.target.value })}
                />
                <input
                  placeholder="Phone"
                  value={driverForm.phone}
                  onChange={(event) => setDriverForm({ ...driverForm, phone: event.target.value })}
                />
                <input
                  placeholder="License number"
                  value={driverForm.license_number}
                  onChange={(event) =>
                    setDriverForm({ ...driverForm, license_number: event.target.value })
                  }
                />
                <select
                  value={driverForm.availability}
                  onChange={(event) =>
                    setDriverForm({ ...driverForm, availability: event.target.value })
                  }
                >
                  <option value="available">available</option>
                  <option value="assigned">assigned</option>
                  <option value="unavailable">unavailable</option>
                </select>
                <button type="submit" className="primary-button">
                  <Plus size={16} />
                  {editingDriverId ? "Update Driver" : "Add Driver"}
                </button>
              </form>
            </section>
            <section className="glass-panel module-card">
              <div className="section-heading">
                <div>
                  <h2>Driver Directory</h2>
                  <p>Full CRUD management for assigned and standby drivers.</p>
                </div>
              </div>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Phone</th>
                      <th>License</th>
                      <th>Availability</th>
                      <th>Assigned Vehicle</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {drivers.map((driver) => (
                      <tr key={driver.id}>
                        <td>{driver.name}</td>
                        <td>{driver.phone}</td>
                        <td>{driver.license_number}</td>
                        <td>{driver.availability}</td>
                        <td>{driver.assigned_vehicle_number || "None"}</td>
                        <td className="actions-cell">
                          <button
                            type="button"
                            className="ghost-button"
                            onClick={() => handleDriverEdit(driver)}
                          >
                            <Pencil size={14} />
                          </button>
                          <button
                            type="button"
                            className="ghost-button danger"
                            onClick={() => handleDriverDelete(driver.id)}
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        ) : null}

        {tab === "orders" ? (
          <section className="glass-panel module-card">
            <div className="section-heading">
              <div>
                <h2>Order Management</h2>
                <p>Update status and assign vehicle/driver from a single table.</p>
              </div>
            </div>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Tracking</th>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>Vehicle</th>
                    <th>Driver</th>
                    <th>ETA</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id}>
                      <td>{order.tracking_number}</td>
                      <td>{order.customer_name}</td>
                      <td>
                        <select
                          value={order.status}
                          onChange={(event) =>
                            handleOrderUpdate(order.id, { status: event.target.value })
                          }
                        >
                          {orderStatusOptions.map((status) => (
                            <option key={status} value={status}>
                              {status}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td>
                        <select
                          value={order.vehicle?.id || ""}
                          onChange={(event) =>
                            handleOrderUpdate(order.id, {
                              vehicle_id: event.target.value ? Number(event.target.value) : null,
                            })
                          }
                        >
                          <option value="">Unassigned</option>
                          {vehicles.map((vehicle) => (
                            <option key={vehicle.id} value={vehicle.id}>
                              {vehicle.vehicle_number}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td>
                        <select
                          value={order.driver?.id || ""}
                          onChange={(event) =>
                            handleOrderUpdate(order.id, {
                              driver_id: event.target.value ? Number(event.target.value) : null,
                            })
                          }
                        >
                          <option value="">Unassigned</option>
                          {drivers.map((driver) => (
                            <option key={driver.id} value={driver.id}>
                              {driver.name}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td>{order.eta || "Not set"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ) : null}

        {tab === "payments" ? (
          <section className="glass-panel module-card">
            <div className="section-heading">
              <div>
                <h2>Payment Monitoring</h2>
                <p>Track transactions and revenue with backend filters.</p>
              </div>
              <select value={paymentFilter} onChange={(event) => setPaymentFilter(event.target.value)}>
                <option value="">All</option>
                <option value="paid">Paid</option>
                <option value="pending">Pending</option>
                <option value="failed">Failed</option>
              </select>
            </div>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Reference</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Method</th>
                    <th>Order</th>
                  </tr>
                </thead>
                <tbody>
                  {payments.map((payment) => (
                    <tr key={payment.id}>
                      <td>{payment.reference}</td>
                      <td>${payment.amount.toFixed(2)}</td>
                      <td>{payment.status}</td>
                      <td>{payment.method}</td>
                      <td>{payment.order?.tracking_number}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ) : null}

        {tab === "alerts" ? (
          <section className="route-grid">
            {alerts.map((alert, index) => (
              <article key={`${alert.type}-${index}`} className="route-card glass-panel">
                <div className="route-top">
                  <h3>{alert.type.replaceAll("_", " ")}</h3>
                  <span className="route-saving">Alert</span>
                </div>
                <p className="route-copy">{alert.message}</p>
              </article>
            ))}
            {!alerts.length ? (
              <div className="module-card glass-panel">
                <p className="empty-state">No active alerts at the moment.</p>
              </div>
            ) : null}
          </section>
        ) : null}
      </main>
    </div>
  );
}
