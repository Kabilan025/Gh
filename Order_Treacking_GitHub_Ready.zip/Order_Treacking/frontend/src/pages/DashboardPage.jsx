import {
  BellRing,
  ChevronRight,
  LayoutDashboard,
  MapPinned,
  Menu,
  Route,
  Truck,
  Wallet,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  downloadInvoice,
  fetchDashboardData,
  fetchFastagReminders,
  fetchPayments,
  fetchRouteSuggestion,
  fetchVehicleLiveTracking,
} from "../api/logistics";
import ChatbotWidget from "../components/chatbot/ChatbotWidget";
import StatCard from "../components/dashboard/StatCard";
import Navbar from "../components/layout/Navbar";
import OrderTimeline from "../components/tracking/OrderTimeline";
import PaymentPanel from "../components/tracking/PaymentPanel";
import VehicleMap from "../components/tracking/VehicleMap";
import usePolling from "../hooks/usePolling";

const chartColors = ["#38bdf8", "#8b5cf6", "#22c55e"];
const menuItems = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "vehicles", label: "Vehicle Tracking", icon: Truck },
  { id: "packages", label: "Package Tracking", icon: MapPinned },
  { id: "fastag", label: "FASTag Reminder", icon: Wallet },
  { id: "routes", label: "Route Suggestions", icon: Route },
];

export default function DashboardPage() {
  const [data, setData] = useState({
    vehicles: [],
    orders: [],
    payments: [],
    metrics: {},
    charts: {
      order_status_counts: {},
      payment_status_counts: {},
    },
  });
  const [activeSection, setActiveSection] = useState("overview");
  const [menuOpen, setMenuOpen] = useState(true);
  const [paymentStatusFilter, setPaymentStatusFilter] = useState("");
  const [paymentData, setPaymentData] = useState({ payments: [], summary: null });
  const [fastagReminders, setFastagReminders] = useState([]);
  const [routeSuggestions, setRouteSuggestions] = useState([]);
  const [routeForm, setRouteForm] = useState({ source: "", destination: "" });
  const [loadingRoute, setLoadingRoute] = useState(false);
  const [pageError, setPageError] = useState("");

  const loadDashboard = useCallback(async () => {
    try {
      const [response, liveVehicles] = await Promise.all([
        fetchDashboardData(),
        fetchVehicleLiveTracking(),
      ]);
      setData({ ...response, vehicles: liveVehicles });
      setPageError("");
    } catch (error) {
      console.error("Failed to load dashboard", error);
      setPageError("Unable to load dashboard data right now.");
    }
  }, []);

  usePolling(loadDashboard, 12000);

  const loadPayments = useCallback(async () => {
    try {
      const response = await fetchPayments(paymentStatusFilter);
      setPaymentData(response);
    } catch (error) {
      console.error("Failed to load payments", error);
    }
  }, [paymentStatusFilter]);

  const loadFastagReminders = useCallback(async () => {
    try {
      setFastagReminders(await fetchFastagReminders());
    } catch (error) {
      console.error("Failed to load FASTag reminders", error);
    }
  }, []);

  useEffect(() => {
    loadPayments();
  }, [loadPayments]);

  useEffect(() => {
    loadFastagReminders();
  }, [loadFastagReminders]);

  const orderChartData = Object.entries(data.charts.order_status_counts || {}).map(
    ([name, value]) => ({ name, value })
  );

  const routeSuggestionCards = useMemo(() => {
    if (routeSuggestions.length) {
      return routeSuggestions;
    }
    return data.orders.map((order) => ({
      id: order.id,
      trackingNumber: order.tracking_number,
      currentRoute: `${order.origin} -> ${order.destination}`,
      suggestion: "Request a backend route suggestion to view optimized distance and ETA.",
      saving: "Awaiting input",
      confidence: "Not calculated",
    }));
  }, [data.orders, routeSuggestions]);

  const handleInvoiceDownload = async (payment) => {
    try {
      const blob = await downloadInvoice(payment.id);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `invoice-${payment.reference}.pdf`;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Failed to download invoice", error);
    }
  };

  const handleRouteSuggestion = async (event) => {
    event.preventDefault();
    if (!routeForm.source || !routeForm.destination) {
      return;
    }
    setLoadingRoute(true);
    try {
      const suggestion = await fetchRouteSuggestion(routeForm);
      setRouteSuggestions([
        {
          id: `${suggestion.source}-${suggestion.destination}`,
          trackingNumber: "Custom Route",
          currentRoute: `${suggestion.source} -> ${suggestion.destination}`,
          suggestion: suggestion.suggested_route,
          saving: `${suggestion.distance_km} km`,
          confidence: `${suggestion.estimated_time_hours} hrs ETA`,
        },
      ]);
    } catch (error) {
      console.error("Failed to load route suggestion", error);
    } finally {
      setLoadingRoute(false);
    }
  };

  const renderOverview = () => (
    <div className="section-stack dashboard-fade">
      <section className="stats-grid">
        <StatCard
          title="Fleet Coverage"
          value={data.metrics.vehicle_count || 0}
          subtitle="vehicles on active routes"
          accent="accent-blue"
        />
        <StatCard
          title="Open Orders"
          value={data.metrics.active_orders || 0}
          subtitle="live package movements"
          accent="accent-violet"
        />
        <StatCard
          title="Pending Payments"
          value={`$${data.metrics.pending_payments || 0}`}
          subtitle="awaiting settlement"
          accent="accent-green"
        />
      </section>

      <section className="hero-grid">
        <div className="hero-card glass-panel">
          <div className="section-heading">
            <div>
              <h2>General User Dashboard</h2>
              <p>One place to watch vehicles, packages, FASTag dues, and route decisions.</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={orderChartData}>
              <XAxis dataKey="name" stroke="#9fb0ff" />
              <YAxis stroke="#9fb0ff" />
              <Tooltip />
              <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                {orderChartData.map((entry, index) => (
                  <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="hero-card glass-panel overview-highlight">
          <div className="section-heading">
            <div>
              <h2>Live Alerts</h2>
              <p>Priority items requiring attention across transport operations.</p>
            </div>
            <BellRing className="highlight-icon" />
          </div>
          <div className="alert-list">
            <div className="alert-row">
              <span className="alert-dot blue" />
              <div>
                <strong>{data.vehicles[0]?.vehicle_number || "No vehicle assigned"}</strong>
                <p>Vehicle location refreshed from the live backend feed.</p>
              </div>
            </div>
            <div className="alert-row">
              <span className="alert-dot green" />
              <div>
                <strong>{data.orders[0]?.tracking_number || "No package yet"}</strong>
                <p>Order timeline is synced with current backend timestamps.</p>
              </div>
            </div>
            <div className="alert-row">
              <span className="alert-dot amber" />
              <div>
                <strong>{fastagReminders[0]?.vehicle_number || "No alert"}</strong>
                <p>{fastagReminders[0]?.message || "FASTag alerts are clear right now."}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="module-grid">
        <OrderTimeline orders={data.orders} />
        <PaymentPanel
          payments={paymentData.payments}
          summary={paymentData.summary}
          statusFilter={paymentStatusFilter}
          onFilterChange={setPaymentStatusFilter}
          onDownloadInvoice={handleInvoiceDownload}
        />
      </section>
    </div>
  );

  const renderVehicles = () => (
    <div className="section-stack dashboard-fade">
      <div className="content-header glass-panel">
        <div>
          <h2>Vehicle Tracking</h2>
          <p>Track live markers, route polylines, and backend ETA updates.</p>
        </div>
      </div>
      <section className="hero-grid">
        <VehicleMap vehicles={data.vehicles} />
        <div className="module-card glass-panel">
          <div className="section-heading">
            <div>
              <h2>Fleet Status</h2>
              <p>Operational state of each assigned vehicle.</p>
            </div>
          </div>
          <div className="info-list">
            {data.vehicles.map((vehicle) => (
              <div key={vehicle.id} className="info-card">
                <div className="info-card-head">
                  <h3>{vehicle.vehicle_number}</h3>
                  <span className="status-badge">{vehicle.status}</span>
                </div>
                <p>{vehicle.route_details}</p>
                <small>
                  Current ETA: {vehicle.current_eta || "Updating"} | Driver:{" "}
                  {vehicle.driver?.name || "Unassigned"}
                </small>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );

  const renderPackages = () => (
    <div className="section-stack dashboard-fade">
      <div className="content-header glass-panel">
        <div>
          <h2>Package Tracking</h2>
          <p>Timeline, timestamps, assigned vehicle, and delivery ETA for each order.</p>
        </div>
      </div>
      <section className="module-grid">
        <OrderTimeline orders={data.orders} />
        <div className="module-card glass-panel">
          <div className="section-heading">
            <div>
              <h2>Package Summary</h2>
              <p>Shipment checkpoints and assignment details from backend order data.</p>
            </div>
          </div>
          <div className="info-list">
            {data.orders.map((order) => (
              <div key={order.id} className="info-card">
                <div className="info-card-head">
                  <h3>{order.tracking_number}</h3>
                  <span className="status-badge">{order.status}</span>
                </div>
                <p>
                  {order.origin} to {order.destination}
                </p>
                <small>
                  ETA: {order.eta || "Awaiting dispatch"} | Vehicle:{" "}
                  {order.vehicle?.vehicle_number || "Unassigned"} | Driver:{" "}
                  {order.driver?.name || "Unassigned"}
                </small>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );

  const renderFastag = () => (
    <div className="section-stack dashboard-fade">
      <div className="content-header glass-panel">
        <div>
          <h2>FASTag Amount Reminder</h2>
          <p>Backend-powered upcoming expiry alerts and overdue FASTag warnings.</p>
        </div>
      </div>
      <section className="fastag-grid">
        {fastagReminders.map((item) => (
          <article
            key={item.vehicle_id}
            className={`fastag-card glass-panel ${item.level === "overdue" ? "urgent" : ""}`}
          >
            <div className="info-card-head">
              <div>
                <h3>{item.vehicle_number}</h3>
                <p>{item.route_details}</p>
              </div>
              <span className="fastag-amount">{item.level}</span>
            </div>
            <div className="fastag-footer">
              <span>{item.message}</span>
              <span>{item.fastag_expiry_date}</span>
            </div>
          </article>
        ))}
        {!fastagReminders.length ? (
          <div className="module-card glass-panel">
            <p className="empty-state">No upcoming or overdue FASTag reminders right now.</p>
          </div>
        ) : null}
      </section>
    </div>
  );

  const renderRoutes = () => (
    <div className="section-stack dashboard-fade">
      <div className="content-header glass-panel">
        <div>
          <h2>Optimized Route Suggestion</h2>
          <p>Backend suggestions are ready for future Google Maps integration.</p>
        </div>
      </div>
      <form className="route-form glass-panel" onSubmit={handleRouteSuggestion}>
        <input
          placeholder="Source city"
          value={routeForm.source}
          onChange={(event) => setRouteForm({ ...routeForm, source: event.target.value })}
        />
        <input
          placeholder="Destination city"
          value={routeForm.destination}
          onChange={(event) => setRouteForm({ ...routeForm, destination: event.target.value })}
        />
        <button type="submit" className="primary-button" disabled={loadingRoute}>
          {loadingRoute ? "Calculating..." : "Get Suggestion"}
        </button>
      </form>
      <section className="route-grid">
        {routeSuggestionCards.map((route) => (
          <article key={route.id} className="route-card glass-panel">
            <div className="route-top">
              <div>
                <h3>{route.trackingNumber}</h3>
                <p>{route.currentRoute}</p>
              </div>
              <span className="route-saving">{route.saving}</span>
            </div>
            <p className="route-copy">{route.suggestion}</p>
            <div className="route-meta">
              <span>{route.confidence}</span>
              <span className="route-arrow">
                Review path <ChevronRight size={16} />
              </span>
            </div>
          </article>
        ))}
      </section>
    </div>
  );

  const renderActiveSection = () => {
    switch (activeSection) {
      case "vehicles":
        return renderVehicles();
      case "packages":
        return renderPackages();
      case "fastag":
        return renderFastag();
      case "routes":
        return renderRoutes();
      default:
        return renderOverview();
    }
  };

  return (
    <div className="page-shell">
      <div className="user-dashboard-shell">
        <aside className={`dashboard-sidebar glass-panel ${menuOpen ? "" : "collapsed"}`}>
          <div className="sidebar-brand">
            <div className="brand-mark">
              <Truck size={20} />
            </div>
            {menuOpen ? (
              <div>
                <h1>LogiPulse</h1>
                <p>General user dashboard</p>
              </div>
            ) : null}
          </div>

          <button
            type="button"
            className="menu-toggle ghost-button"
            onClick={() => setMenuOpen((value) => !value)}
            aria-label="Toggle navigation menu"
          >
            <Menu size={18} />
            {menuOpen ? <span>Menu</span> : null}
          </button>

          <nav className="sidebar-nav">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  className={`sidebar-link ${activeSection === item.id ? "active" : ""}`}
                  onClick={() => setActiveSection(item.id)}
                >
                  <Icon size={18} />
                  {menuOpen ? <span>{item.label}</span> : null}
                </button>
              );
            })}
          </nav>
        </aside>

        <div className="dashboard-main">
          <Navbar title="Customer control view" />
          <main className="dashboard-layout dashboard-layout-wide">
            {pageError ? <div className="error-banner">{pageError}</div> : null}
            {renderActiveSection()}
          </main>
        </div>
      </div>
      <ChatbotWidget />
    </div>
  );
}
