import { useEffect } from "react";

export default function usePolling(callback, delay = 10000) {
  useEffect(() => {
    callback();
    const timer = setInterval(callback, delay);
    return () => clearInterval(timer);
  }, [callback, delay]);
}
