import api from "./client";

export const fetchDashboardData = async () => {
  const { data } = await api.get("/dashboard");
  return data;
};

export const fetchVehicles = async () => {
  const { data } = await api.get("/vehicles");
  return data.vehicles;
};

export const fetchVehicleLiveTracking = async () => {
  const { data } = await api.get("/vehicle-live-tracking");
  return data.vehicles;
};

export const createVehicle = async (payload) => {
  const { data } = await api.post("/vehicles", payload);
  return data.vehicle;
};

export const updateVehicle = async (id, payload) => {
  const { data } = await api.put(`/vehicles/${id}`, payload);
  return data.vehicle;
};

export const deleteVehicle = async (id) => {
  const { data } = await api.delete(`/vehicles/${id}`);
  return data;
};

export const fetchOrders = async () => {
  const { data } = await api.get("/orders");
  return data.orders;
};

export const createOrder = async (payload) => {
  const { data } = await api.post("/orders", payload);
  return data.order;
};

export const updateOrder = async (id, payload) => {
  const { data } = await api.put(`/orders/${id}`, payload);
  return data.order;
};

export const fetchPayments = async (status = "") => {
  const { data } = await api.get("/payments", { params: status ? { status } : {} });
  return data;
};

export const downloadInvoice = async (paymentId) => {
  const response = await api.get(`/payments/${paymentId}/invoice`, {
    responseType: "blob",
  });
  return response.data;
};

export const fetchFastagReminders = async () => {
  const { data } = await api.get("/fastag-reminders");
  return data.reminders;
};

export const fetchRouteSuggestion = async (payload) => {
  const { data } = await api.post("/route-suggestions", payload);
  return data.suggestion;
};

export const fetchDrivers = async () => {
  const { data } = await api.get("/drivers");
  return data.drivers;
};

export const createDriver = async (payload) => {
  const { data } = await api.post("/drivers", payload);
  return data.driver;
};

export const updateDriver = async (id, payload) => {
  const { data } = await api.put(`/drivers/${id}`, payload);
  return data.driver;
};

export const deleteDriver = async (id) => {
  const { data } = await api.delete(`/drivers/${id}`);
  return data;
};

export const fetchAdminOverview = async () => {
  const { data } = await api.get("/admin/overview");
  return data;
};

export const fetchAlerts = async () => {
  const { data } = await api.get("/alerts");
  return data.alerts;
};

export const sendChatMessage = async (message) => {
  const { data } = await api.post("/chatbot", { message });
  return data.reply;
};
