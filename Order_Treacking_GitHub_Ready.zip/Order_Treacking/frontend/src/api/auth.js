import api from "./client";

export const loginUser = async (payload) => {
  const { data } = await api.post("/auth/login", payload);
  return data;
};

export const registerUser = async (payload) => {
  const { data } = await api.post("/auth/register", payload);
  return data;
};

export const googleLogin = async (credential) => {
  const { data } = await api.post("/auth/google", { credential });
  return data;
};
