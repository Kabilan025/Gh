import { Fragment } from "react";
import { MapContainer, Marker, Polyline, Popup, TileLayer } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const icon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

export default function VehicleMap({ vehicles = [] }) {
  const center = vehicles[0]
    ? [vehicles[0].latitude, vehicles[0].longitude]
    : [20.5937, 78.9629];

  return (
    <div className="module-card glass-panel">
      <div className="section-heading">
        <div>
          <h2>Vehicle Tracking</h2>
          <p>Live fleet position powered by Leaflet maps.</p>
        </div>
      </div>
      <MapContainer center={center} zoom={5} className="map-frame" scrollWheelZoom>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {vehicles.map((vehicle) => (
          <Fragment key={vehicle.id}>
            {vehicle.path?.length ? (
              <Polyline
                positions={vehicle.path}
                pathOptions={{ color: "#22c55e", weight: 4, opacity: 0.75 }}
              />
            ) : null}
            <Marker position={[vehicle.latitude, vehicle.longitude]} icon={icon}>
              <Popup>
                <strong>{vehicle.vehicle_number}</strong>
                <br />
                {vehicle.route_details}
                <br />
                ETA: {vehicle.current_eta || "Updating"}
                <br />
                Driver: {vehicle.driver?.name || "Unassigned"}
              </Popup>
            </Marker>
          </Fragment>
        ))}
      </MapContainer>
    </div>
  );
}
