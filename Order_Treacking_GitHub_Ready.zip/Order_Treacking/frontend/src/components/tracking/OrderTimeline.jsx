const stageLabels = {
  ordered: "Ordered",
  packed: "Packed",
  shipped: "Shipped",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered",
  delayed: "Delayed",
};

export default function OrderTimeline({ orders = [] }) {
  return (
    <div className="module-card glass-panel">
      <div className="section-heading">
        <div>
          <h2>Order Tracking</h2>
          <p>Shipment progress across each fulfillment stage.</p>
        </div>
      </div>
      <div className="timeline-list">
        {orders.map((order) => (
          <div key={order.id} className="timeline-card">
            <div>
              <h3>{order.tracking_number}</h3>
              <p>
                {order.origin} to {order.destination}
              </p>
            </div>
            <div className="timeline-steps">
              {(order.timeline || []).map((stage) => (
                <div
                  key={stage.status}
                  className={`timeline-step ${stage.completed ? "active" : ""}`}
                >
                  <span />
                  <small>{stageLabels[stage.status] || stage.status}</small>
                  <em>{stage.timestamp ? new Date(stage.timestamp).toLocaleString() : "Pending"}</em>
                </div>
              ))}
            </div>
            <div className="order-meta">
              <strong className="eta-text">ETA: {order.eta || "Pending update"}</strong>
              <small>
                Vehicle: {order.vehicle?.vehicle_number || "Unassigned"} | Driver:{" "}
                {order.driver?.name || "Unassigned"}
              </small>
            </div>
          </div>
        ))}
        {!orders.length && <p className="empty-state">No orders assigned yet.</p>}
      </div>
    </div>
  );
}
