export default function PaymentPanel({
  payments = [],
  summary = null,
  statusFilter = "",
  onFilterChange,
  onDownloadInvoice,
}) {
  return (
    <div className="module-card glass-panel">
      <div className="section-heading">
        <div>
          <h2>Payment Tracking</h2>
          <p>Billing history with live status highlights.</p>
        </div>
        {onFilterChange ? (
          <select value={statusFilter} onChange={(event) => onFilterChange(event.target.value)}>
            <option value="">All</option>
            <option value="paid">Paid</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
          </select>
        ) : null}
      </div>
      {summary ? (
        <div className="payment-summary-grid">
          <div className="mini-summary-card">
            <span>Total Payments</span>
            <strong>${summary.total_payments?.toFixed?.(2) ?? summary.total_payments}</strong>
          </div>
          <div className="mini-summary-card">
            <span>Pending Payments</span>
            <strong>
              ${summary.pending_payments?.toFixed?.(2) ?? summary.pending_payments}
            </strong>
          </div>
        </div>
      ) : null}
      <div className="payment-grid">
        {payments.map((payment) => (
          <div key={payment.id} className="payment-card">
            <div className="payment-row">
              <h3>{payment.reference}</h3>
              <span className={`status-pill ${payment.status}`}>{payment.status}</span>
            </div>
            <p>${payment.amount.toFixed(2)}</p>
            <small>
              {payment.method} for {payment.order?.tracking_number}
            </small>
            {onDownloadInvoice ? (
              <button
                type="button"
                className="ghost-button payment-action"
                onClick={() => onDownloadInvoice(payment)}
              >
                Download Invoice
              </button>
            ) : null}
          </div>
        ))}
        {!payments.length && <p className="empty-state">No payments recorded yet.</p>}
      </div>
    </div>
  );
}
