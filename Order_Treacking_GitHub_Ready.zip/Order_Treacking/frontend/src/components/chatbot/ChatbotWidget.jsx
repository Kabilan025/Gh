import { Bot, SendHorizontal, X } from "lucide-react";
import { useState } from "react";
import { sendChatMessage } from "../../api/logistics";

const starterMessages = [
  {
    sender: "bot",
    text: "Hi, I can help with order status, vehicles, and payments.",
  },
];

export default function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState(starterMessages);
  const [loading, setLoading] = useState(false);

  const handleSend = async (event) => {
    event.preventDefault();
    if (!input.trim() || loading) {
      return;
    }

    const nextMessages = [...messages, { sender: "user", text: input }];
    setMessages(nextMessages);
    setLoading(true);

    try {
      const reply = await sendChatMessage(input);
      setMessages([...nextMessages, { sender: "bot", text: reply }]);
      setInput("");
    } catch (error) {
      setMessages([
        ...nextMessages,
        { sender: "bot", text: "The assistant is temporarily unavailable." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button type="button" className="chat-fab" onClick={() => setOpen((value) => !value)}>
        {open ? <X size={20} /> : <Bot size={20} />}
      </button>
      {open && (
        <div className="chat-panel glass-panel">
          <div className="chat-header">
            <div>
              <h3>Support Bot</h3>
              <p>Tracking and billing assistant</p>
            </div>
          </div>
          <div className="chat-messages">
            {messages.map((message, index) => (
              <div key={`${message.sender}-${index}`} className={`bubble ${message.sender}`}>
                {message.text}
              </div>
            ))}
          </div>
          <form className="chat-form" onSubmit={handleSend}>
            <input
              value={input}
              onChange={(event) => setInput(event.target.value)}
              placeholder="Ask about an order or payment..."
            />
            <button type="submit" className="primary-button" disabled={loading}>
              <SendHorizontal size={16} />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
