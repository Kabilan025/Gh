import { LogOut, PackageCheck, Shield } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

export default function Navbar({ title, admin = false }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate(admin ? "/admin/login" : "/login");
  };

  return (
    <header className="topbar glass-panel">
      <div className="brand">
        <div className="brand-mark">
          {admin ? <Shield size={20} /> : <PackageCheck size={20} />}
        </div>
        <div>
          <h1>LogiPulse</h1>
          <p>{title}</p>
        </div>
      </div>
      <div className="topbar-actions">
        <div className="user-chip">
          <span>{user?.name}</span>
          <small>{user?.role}</small>
        </div>
        <button type="button" className="ghost-button" onClick={handleLogout}>
          <LogOut size={16} />
          Logout
        </button>
      </div>
    </header>
  );
}
