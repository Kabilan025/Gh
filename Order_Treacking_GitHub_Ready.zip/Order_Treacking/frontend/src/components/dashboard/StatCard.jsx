export default function StatCard({ title, value, accent, subtitle }) {
  return (
    <div className={`stat-card glass-panel ${accent}`}>
      <p>{title}</p>
      <h3>{value}</h3>
      <span>{subtitle}</span>
    </div>
  );
}
